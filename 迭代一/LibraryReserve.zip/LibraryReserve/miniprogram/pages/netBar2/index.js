Page({
    data: {
        price: '0',
        name: ' '
    },

    reserve(e) {
        var str1 = e.currentTarget.dataset.name
        var str2 = e.currentTarget.dataset.price
        wx.navigateTo({
            url: '/pages/submitOrder/index?barName=滨海图书馆&seatName='+str1+'&seatPrice='+str2,
            success: function(res) {
                console.log("sucess")
            },
            fail: function(res) {
                console.log("fail")
            },
            complete: function(res) {
                console.log("complete")
            },
        })
    },
    
})