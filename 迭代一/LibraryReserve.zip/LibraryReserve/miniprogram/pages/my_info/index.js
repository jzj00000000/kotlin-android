Page({

    /**
     * 页面的初始数据
     */
    data: {
        avatarUrl: ' ',
        nickName: ' ',
        inputText: '',
        inputText2: ''
    },
    onShow() {
        const self = this
        let userText = wx.getStorageSync('userText')
        let userText2 = wx.getStorageSync('userText2')
        if (userText) {
            self.data.inputText = userText
            self.setData(self.data)
        } // page载入的时候先读取一次，wx.getStorageSync('userText')里面有没有内容，有内容就填充，没有则什么也不做
        if (userText) {
            self.data.inputText2 = userText2
            self.setData(self.data)
        }
    },

    onInputText(e) {
        const self = this
        const value = e.detail.value
        if (value) {
            wx.setStorageSync('userText', value)
        } // 监听用户输入的信息，一旦有内容输入进去，就会使用wx.setStorageSync('userText', value)设置usertext这个key的值，使用wx.getStorageSync('userText')可以得到usertext这个key的值
    },
    onInputText2(e) {
        const self = this
        const value = e.detail.value
        if (value) {
            wx.setStorageSync('userText2', value)
        } // 监听用户输入的信息，一旦有内容输入进去，就会使用wx.setStorageSync('userText', value)设置usertext这个key的值，使用wx.getStorageSync('userText')可以得到usertext这个key的值
    },


    /**
     * 生命周期函数--监听页面加载
     */
    useryearInput:function(e)
    {
     
        this.data.inputText1 = e.detail.value

    },
    onLoad: function (options) {
           
        var avatarUrl = options.avatarUrl
        var nickName = options.nickName
        this.setData({
            'avatarUrl': avatarUrl,
            'nickName': nickName,
            
          })
          console.log(avatarUrl);
},

    

      

})
    
