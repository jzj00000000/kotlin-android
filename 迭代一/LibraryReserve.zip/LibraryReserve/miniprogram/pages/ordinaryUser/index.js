Page({

    data: {
      netBarList: [{
          id: '20211007001',
          name: '滨海极速网吧',
          page: 'netBar1'
        },
        {
            id: '20211007002',
            name: '天津电竞网吧',
            page: 'netBar2'
        }],
    },

    jumpSearch(e) {
        wx.showModal({
            title: '',
            content: '尚在开发中，敬请期待',
            success(res) {
             if (res.confirm) {
              console.log('用户点击确定')
             } else if (res.cancel) {
              console.log('用户点击取消')
             }
            }
           });
    },

    jumpSearchNearbyBar(e) {
        wx.showModal({
            title: '',
            content: '尚在开发中，敬请期待',
            success(res) {
             if (res.confirm) {
              console.log('用户点击确定')
             } else if (res.cancel) {
              console.log('用户点击取消')
             }
            }
           });
    },

    jumpBarDetail1(e) {
        wx.navigateTo({
          url: '/pages/netBar1/index',
        });
    },

    jumpBarDetail2(e) {
        wx.navigateTo({
          url: '/pages/netBar2/index',
        });
    },
})