// pages/order/index.js
Page({

    /**
     * 页面的初始数据
     */
    data: {
        barName: ' ',
        seatName: ' ',
        seatPrice: 1,
        num: 1,
        startTime: new Date(153)
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
            var price = parseInt(options.seatPrice)
            var barName = options.barName
            var seatName = options.seatName
        
            this.setData({
              'barName': barName,
              'seatName': seatName,
              'seatPrice': price
            })

        console.log(barName);
    },

    /* 加数 */
  addCount: function (e) {
    console.log("刚刚您点击了加1");
    var num = this.data.num;
    // 总数量-1  
    if (num < 1000) {
      this.data.num++;
    }
    // 将数值与状态写回  
    this.setData({
      num: this.data.num
    });
  },

      /* 减数 */
  delCount: function (e) {
    console.log("刚刚您点击了减1");
    var num = this.data.num;
    // 商品总数量-1
    if (num > 1) {
      this.data.num--;
    }
    // 将数值与状态写回  
    this.setData({
      num: this.data.num
    });
  },

  getCount: function (e) {
    var num = this.data.num;
    console.log(num);
    wx.showToast({
      title: "数量：" + num + "",
    })
    const db = wx.cloud.database()
    db.collection('order').add({
      // data 字段表示需新增的 JSON 数据
      data: {
        // _id: 'todo-identifiant-aleatoire', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以了
        netBarName: this.data.barName,
        startTime: (new Date()).toLocaleString(),
        duration: num,
        seatName: this.data.seatName,
        endTime: (new Date(((new Date()).getTime())+3600000*num)).toLocaleString(),
        seatRank: 0,
        price: this.data.seatPrice * num,
      },
      success: function(res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        console.log(res)
      }
    })
    wx.redirectTo({
      url: '/pages/submitSuccess/index',
    })
  }

})