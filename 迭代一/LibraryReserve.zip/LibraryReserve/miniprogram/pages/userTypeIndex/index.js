Page({
    jumpUser(e) {
        wx.redirectTo({
          url: '/pages/ordinaryUser/index',
        });
      },

      jumpNetBarAdmin(e) {
        wx.showModal({
            title: '',
            content: '尚在开发中，敬请期待',
            success(res) {
             if (res.confirm) {
              console.log('用户点击确定')
             } else if (res.cancel) {
              console.log('用户点击取消')
             }
            }
           })
      },
})