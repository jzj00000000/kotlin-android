const envList = [{"envId":"cloud1-5g4l6c50caeb5358","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}